package in.countrybaskets.signupandsignin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class home extends AppCompatActivity {
Button ctoast,popup;
Toast toast;
Spinner spin;
String[]  names={"Eswar","anjali","praksh","prakruthi","anandh","vallabh"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ctoast=findViewById(R.id.customtoast);
        spin=findViewById(R.id.spinner1);
        popup=findViewById(R.id.popupactivity);

        popup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(home.this,popup.class);
                startActivity(i);
                finish();
            }
        });
        ArrayAdapter arrayAdapter=new ArrayAdapter(getApplicationContext(),R.layout.support_simple_spinner_dropdown_item,names);
            arrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
            spin.setAdapter(arrayAdapter);


            spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    Toast.makeText(home.this, "welcome "+names[i], Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });


        ctoast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toast=Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER,0,0);
                View v=getLayoutInflater().inflate(R.layout.toast_custom,(ViewGroup)findViewById(R.id.custom_toast_call));
                toast.setView(v);
                toast.show();
            }
        });



    }
}